# Secure Implementation Workflow

1. Understand the requested behavior.
2. Identify assets and trust boundaries.
3. Identify untrusted inputs.
4. Choose safe APIs and validation rules.
5. Implement the smallest robust change.
6. Avoid unnecessary dependencies and attack surface.
7. Add security-focused tests.
8. Run relevant project tests.
9. Run available security checks.
10. Review the final diff for security regressions.
11. Report residual risk and Security Gate status.
