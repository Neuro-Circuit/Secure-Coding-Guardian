# Release Security Gate Workflow

1. Define the release scope.
2. Confirm relevant tests pass.
3. Run applicable security regression tests.
4. Run available static analysis.
5. Audit dependencies.
6. Review secrets.
7. Review authentication and authorization.
8. Review network and filesystem security where applicable.
9. Review native memory safety and build hardening where applicable.
10. Review known findings and residual risk.
11. Record unavailable checks.
12. Assign PASS, PASS WITH WARNINGS, FAIL, or UNKNOWN.
13. Do not call a release security-ready when a known critical issue remains.
