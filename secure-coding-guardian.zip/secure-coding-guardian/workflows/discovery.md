# Discovery Workflow

1. Read `CLAUDE.md` and repository guidance.
2. Identify languages, frameworks, build systems, package managers, and runtimes.
3. Identify entry points and externally controlled inputs.
4. Identify trust boundaries and privileged operations.
5. Identify authentication, authorization, data stores, network access, filesystem access, subprocesses, IPC, plugins, serialization, and FFI.
6. Detect existing tests and security tools.
7. Select security profiles.
8. Load only relevant references.
9. Record material unknowns before implementation or review.
