# Security Review Workflow

1. Inspect project context.
2. Classify the application.
3. Build a threat model proportional to risk.
4. Review entry points and trust boundaries.
5. Review authentication and authorization.
6. Review input validation and injection.
7. Review filesystem, process, network, serialization, and concurrency behavior as applicable.
8. Review secrets and dependencies.
9. Run available static/dynamic tools.
10. Validate important findings.
11. Add regression tests for confirmed issues where practical.
12. Review the final diff.
13. Produce findings and Security Gate.
