# Example: C++ Network Parser

## Scenario

A C++ service parses attacker-controlled network messages.

## Expected Security Focus

- Buffer boundaries
- Integer overflow
- Length-field validation
- Object lifetime
- Parser state
- Undefined behavior
- Resource exhaustion
- Concurrency
- ASan/UBSan
- Static analysis
- Fuzzing

## Expected Workflow

Threat model the network boundary, review parser invariants, run sanitizer-assisted tests where possible, fuzz malformed inputs, and add regression tests for confirmed bugs.
