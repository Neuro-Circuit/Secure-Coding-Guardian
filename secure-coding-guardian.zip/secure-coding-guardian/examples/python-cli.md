# Example: Python CLI Project

## Scenario

A CLI accepts paths and options from users, reads configuration, and invokes external programs.

## Expected Security Focus

- Argument injection
- Command injection
- Path traversal
- Symlink and TOCTOU issues
- Unsafe subprocess usage
- Temporary files
- Environment manipulation
- Configuration permissions
- Secrets

## Expected Workflow

Identify input boundaries and process execution first, then review filesystem and privilege boundaries, add regression tests, and report unavailable checks explicitly.
