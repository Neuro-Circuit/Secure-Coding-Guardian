# Example: C Native Application

## Scenario

A native C utility reads local configuration and processes externally supplied files.

## Expected Security Focus

- Memory safety
- Integer handling
- File/path security
- Symlinks and TOCTOU
- Parser robustness
- Privilege boundaries
- Compiler hardening
- Sanitizers

## Expected Workflow

Identify file and privilege trust boundaries, inspect dangerous memory operations, use static analysis and sanitizers where available, and record residual risk.
