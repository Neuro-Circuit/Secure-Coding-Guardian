# Example: Python Web Project

## Scenario

A FastAPI service exposes authenticated endpoints backed by a relational database and makes outbound HTTP requests.

## Expected Security Focus

- Authentication
- Authorization and IDOR/BOLA
- SQL injection
- SSRF
- Request and response limits
- Secrets
- CORS
- Dependency vulnerabilities
- Error handling

## Expected Workflow

Discovery → Python Web profile → threat model → secure implementation/review → static analysis → dependency audit → security tests → regression tests → final Security Gate.

The Skill should not treat a clean static scan as proof that authorization or SSRF is secure.
