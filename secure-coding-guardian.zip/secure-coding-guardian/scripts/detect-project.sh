#!/usr/bin/env bash
set -u

echo "=== Secure Coding Guardian: Project Detection ==="

if [[ -f CLAUDE.md ]]; then echo "CLAUDE.md: yes"; else echo "CLAUDE.md: no"; fi
if [[ -f pyproject.toml || -f requirements.txt || -f setup.py || -f poetry.lock ]]; then echo "Python: detected"; fi
if find . -maxdepth 3 \( -name '*.c' -o -name '*.h' \) -print -quit 2>/dev/null | grep -q .; then echo "C: detected"; fi
if find . -maxdepth 3 \( -name '*.cpp' -o -name '*.cc' -o -name '*.cxx' -o -name '*.hpp' \) -print -quit 2>/dev/null | grep -q .; then echo "C++: detected"; fi
if [[ -f CMakeLists.txt ]]; then echo "CMake: detected"; fi
if [[ -f Makefile ]]; then echo "Make: detected"; fi
if [[ -f meson.build ]]; then echo "Meson: detected"; fi
if [[ -d .github/workflows ]]; then echo "GitHub Actions: detected"; fi
if [[ -f Dockerfile ]]; then echo "Dockerfile: detected"; fi

echo "=== Candidate Security Tools ==="
for tool in python3 pip-audit bandit semgrep osv-scanner clang clang-tidy cppcheck cmake make; do
  if command -v "$tool" >/dev/null 2>&1; then
    echo "$tool: available"
  else
    echo "$tool: unavailable"
  fi
done
