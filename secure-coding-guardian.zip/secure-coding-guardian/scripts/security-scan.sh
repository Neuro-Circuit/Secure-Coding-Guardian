#!/usr/bin/env bash
set -u

echo "=== Secure Coding Guardian: Available Security Checks ==="

run_if_available() {
  local label="$1"
  shift
  if command -v "$1" >/dev/null 2>&1; then
    echo "--- $label ---"
    "$@" || echo "$label exited with status $?"
  else
    echo "--- $label: unavailable ---"
  fi
}

if [[ -f pyproject.toml || -f requirements.txt ]]; then
  run_if_available "pip-audit" pip-audit
  run_if_available "bandit" bandit -r .
fi

run_if_available "osv-scanner" osv-scanner --help
run_if_available "semgrep" semgrep --version

if find . -maxdepth 3 \( -name '*.c' -o -name '*.cpp' -o -name '*.cc' -o -name '*.cxx' \) -print -quit 2>/dev/null | grep -q .; then
  run_if_available "clang" clang --version
  run_if_available "clang-tidy" clang-tidy --version
  run_if_available "cppcheck" cppcheck --version
fi

echo "Note: this helper intentionally does not claim that a scan passed."
echo "Interpret results in project context and record unavailable checks."
