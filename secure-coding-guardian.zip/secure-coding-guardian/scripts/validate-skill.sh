#!/usr/bin/env bash
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ERRORS=0

required=(
  "SKILL.md"
  "README.md"
  "LICENSE"
  "workflows/discovery.md"
  "workflows/secure-implementation.md"
  "workflows/security-review.md"
  "workflows/vulnerability-remediation.md"
  "workflows/release-security-gate.md"
  "checklists/python.md"
  "checklists/c.md"
  "checklists/cpp.md"
  "checklists/web.md"
  "checklists/native.md"
  "checklists/final-security-gate.md"
)

for f in "${required[@]}"; do
  if [[ ! -f "$ROOT/$f" ]]; then
    echo "MISSING: $f"
    ERRORS=$((ERRORS + 1))
  fi
done

if ! grep -q '^name: secure-coding-guardian$' "$ROOT/SKILL.md"; then
  echo "ERROR: unexpected Skill name"
  ERRORS=$((ERRORS + 1))
fi

if ! grep -q '^description:' "$ROOT/SKILL.md"; then
  echo "ERROR: missing description"
  ERRORS=$((ERRORS + 1))
fi

if [[ "$ERRORS" -eq 0 ]]; then
  echo "Skill validation: PASS"
  exit 0
else
  echo "Skill validation: FAIL ($ERRORS issue(s))"
  exit 1
fi
