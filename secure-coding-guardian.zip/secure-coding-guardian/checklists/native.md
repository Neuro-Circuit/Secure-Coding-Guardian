# Native Security Checklist

- [ ] Memory safety has been reviewed.
- [ ] Integer arithmetic and conversions are reviewed.
- [ ] Parser boundaries are identified.
- [ ] Undefined behavior risks are considered.
- [ ] Filesystem permissions are appropriate.
- [ ] Process execution is constrained.
- [ ] Privilege boundaries are explicit.
- [ ] IPC is authenticated/authorized where required.
- [ ] Compiler/linker hardening is considered.
- [ ] Sanitizers are used in testing where feasible.
- [ ] Fuzzing is considered for untrusted parsers.
