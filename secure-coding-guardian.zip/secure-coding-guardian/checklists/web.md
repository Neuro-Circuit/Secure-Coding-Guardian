# Web Security Checklist

- [ ] Authentication is correctly enforced.
- [ ] Authorization is checked per resource/action.
- [ ] IDOR/BOLA is considered.
- [ ] Injection defenses use appropriate safe APIs.
- [ ] CSRF protection is appropriate.
- [ ] CORS is restrictive and intentional.
- [ ] SSRF controls are present where needed.
- [ ] File uploads are validated and constrained.
- [ ] Path traversal is prevented.
- [ ] Output encoding is contextual.
- [ ] Session/token handling is reviewed.
- [ ] Rate and resource limits exist where needed.
- [ ] Errors do not disclose sensitive internals.
- [ ] Security events are logged without secrets.
