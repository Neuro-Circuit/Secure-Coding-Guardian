# C Security Checklist

- [ ] External input boundaries are identified.
- [ ] Buffer sizes and copy lengths are checked.
- [ ] Allocation-size arithmetic is safe.
- [ ] Integer conversions are reviewed.
- [ ] Out-of-bounds access is ruled out for reviewed paths.
- [ ] Lifetime and ownership are clear.
- [ ] Use-after-free/double-free paths are reviewed.
- [ ] Uninitialized reads are considered.
- [ ] Format strings are safe.
- [ ] Undefined behavior is considered.
- [ ] Parser error paths are reviewed.
- [ ] TOCTOU/race conditions are considered.
- [ ] Privilege boundaries are reviewed.
- [ ] Compiler warnings are enabled appropriately.
- [ ] Sanitizers are used where feasible.
- [ ] Static analysis is run where available.
- [ ] Fuzzing is considered for parsers.
