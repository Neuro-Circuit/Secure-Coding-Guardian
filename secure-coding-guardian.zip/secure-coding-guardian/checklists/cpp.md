# C++ Security Checklist

- [ ] Ownership is explicit.
- [ ] RAII is used for resource management.
- [ ] Owning raw pointers are avoided where practical.
- [ ] Lifetime of references and pointers is reviewed.
- [ ] Iterator invalidation is considered.
- [ ] Unsafe casts are minimized.
- [ ] Exception/error paths preserve invariants.
- [ ] Move operations are reviewed.
- [ ] Concurrency and data races are considered.
- [ ] Serialization/parsing is reviewed.
- [ ] Filesystem and subprocess operations are reviewed.
- [ ] FFI/ABI boundaries are reviewed.
- [ ] Sanitizers are used where feasible.
- [ ] Static analysis is run where available.
- [ ] Fuzzing is considered for parsers.
