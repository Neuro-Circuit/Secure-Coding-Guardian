# Python Security Checklist

## Input and Execution

- [ ] Untrusted input is identified.
- [ ] `eval`/`exec`/unsafe dynamic evaluation is absent or justified and constrained.
- [ ] Subprocess execution avoids unnecessary shell interpretation.
- [ ] Arguments are validated.

## Files

- [ ] Paths are validated and canonicalized where required.
- [ ] Traversal and absolute-path injection are addressed.
- [ ] Symlink and TOCTOU risks are considered.
- [ ] Temporary files use safe mechanisms.
- [ ] Archive extraction is constrained.

## Serialization and Parsing

- [ ] Unsafe object deserialization is avoided.
- [ ] YAML loaders are safe.
- [ ] XML parsing is configured appropriately.
- [ ] Parser and input-size limits exist where needed.

## Web

- [ ] Authentication is reviewed.
- [ ] Authorization is enforced server-side.
- [ ] IDOR/BOLA is considered.
- [ ] Injection is prevented.
- [ ] SSRF is addressed.
- [ ] CSRF/CORS are reviewed.
- [ ] File uploads are constrained.
- [ ] Rate/resource limits are considered.

## Secrets and Dependencies

- [ ] Secrets are not hard-coded.
- [ ] Logs do not expose secrets.
- [ ] Dependencies are audited.
- [ ] Lockfiles are reviewed.
