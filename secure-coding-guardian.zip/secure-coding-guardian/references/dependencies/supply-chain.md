# Dependency and Supply-Chain Reference

Review:

- Direct dependencies
- Transitive dependencies
- Lockfiles
- Package sources
- Build tools
- Compiler toolchains
- Downloaded binaries
- Install scripts
- Plugins

Prefer reproducible dependency resolution and known trusted sources. Run available vulnerability auditing tools and record what was actually checked.
