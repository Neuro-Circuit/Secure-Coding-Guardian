# Python Security Reference

## Dangerous execution

Review `eval`, `exec`, `compile`, dynamic imports, and expression/template evaluation. Prefer explicit dispatch tables and safe parsers.

## Process execution

Prefer argument arrays and direct process APIs. Avoid shell interpretation when it is unnecessary. Treat executable names, arguments, environment, working directories, and inherited file descriptors as security-sensitive.

## Deserialization

Do not deserialize attacker-controlled data with `pickle`, `marshal`, or equivalent unsafe object formats. Use constrained, schema-driven formats where possible.

## YAML and XML

Use safe YAML loaders. Configure XML parsers to avoid external entity and related resource-resolution risks when untrusted XML is accepted.

## Filesystem

Canonicalize and validate paths at the trust boundary. Consider traversal, absolute paths, symlinks, TOCTOU, permissions, and race conditions.

## Archives

Do not blindly extract archive members. Validate normalized destinations and account for symlinks, absolute names, and resource exhaustion.

## Web

Review authentication, authorization, CSRF, CORS, SSRF, injection, XSS, SSTI, file uploads, redirects, sessions, and resource limits.

## Regex and parsers

Treat complex regular expressions and unbounded parsing as potential availability risks. Bound input size and complexity.

## Secrets

Do not place credentials or private keys in source, logs, tests, or error messages. Use appropriate secret-management mechanisms.

## Dependencies

Audit direct and transitive dependencies and keep lockfiles consistent with the intended dependency set.
