# C Secure Coding Reference

Prefer explicit bounds, checked lengths, well-defined ownership, and clear error handling.

Review:

- `memcpy`, `memmove`, `strcpy`, `strncpy`, `strcat`, `sprintf`, `snprintf`
- Format strings
- Integer conversions
- Allocation calculations
- File and process APIs
- Environment variables
- Path handling
- Privilege changes
- Race-prone filesystem operations

Compiler warnings and hardening should be enabled according to project compatibility requirements.
