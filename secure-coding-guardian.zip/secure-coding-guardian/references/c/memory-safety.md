# C Memory Safety Reference

Review every externally influenced memory operation.

## Common hazards

- Buffer overflow
- Out-of-bounds access
- Use-after-free
- Double free
- Invalid free
- Uninitialized reads
- Null dereference
- Integer overflow affecting allocation or bounds
- Lifetime errors
- Pointer arithmetic
- String termination errors
- Undefined behavior

## Review strategy

Trace sizes from input to allocation and copy operations. Check integer conversions before arithmetic. Verify that bounds remain valid across error paths and concurrent operations.

## Tooling

When feasible, use ASan, UBSan, LSan, TSan, MSan, static analyzers, and fuzzing. Record tool availability and configuration.
