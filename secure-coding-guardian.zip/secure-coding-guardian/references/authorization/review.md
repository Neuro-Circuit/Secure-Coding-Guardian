# Authorization Review

For every protected resource and operation, identify:

- Required role or capability
- Resource ownership
- Tenant boundary
- Server-side enforcement point
- Failure behavior

Test or reason about horizontal privilege escalation, vertical escalation, IDOR/BOLA, and missing function-level checks.
