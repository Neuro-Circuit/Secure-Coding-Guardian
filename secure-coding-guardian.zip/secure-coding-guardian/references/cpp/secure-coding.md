# C++ Secure Coding Reference

Prefer RAII and explicit ownership.

Review:

- Raw owning pointers
- Smart-pointer ownership
- Object lifetime
- Dangling references
- Iterator invalidation
- Unsafe casts
- Exception paths
- Move operations
- Concurrency
- Serialization
- Filesystem
- Subprocess execution
- FFI and ABI boundaries

Avoid unnecessary `reinterpret_cast`, C-style casts, manual allocation, and unsafe C APIs.

Use sanitizer and static-analysis tooling when feasible.
