# Cryptography Reference

Do not invent cryptographic algorithms or protocols.

Prefer established libraries and modern, documented primitives.

Review:

- Algorithm selection
- Key generation and storage
- Randomness
- Key sizes
- IV/nonce generation and uniqueness
- Password hashing
- Authentication/encryption modes
- TLS validation
- Certificate/hostname validation
- Rotation and revocation

Do not disable certificate validation as a workaround.
