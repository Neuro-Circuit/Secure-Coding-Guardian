# Authentication Review

Check:

- Credential storage
- Password hashing
- Session creation and invalidation
- Token validation
- Credential recovery
- Brute-force resistance
- MFA where appropriate
- Account enumeration risks
- Secure defaults

Authentication establishes identity; it does not establish authorization.
