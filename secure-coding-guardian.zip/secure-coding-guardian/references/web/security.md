# Web and API Security Reference

## Authentication

Verify credential handling, session lifecycle, token validation, recovery flows, brute-force controls, and invalidation.

## Authorization

Enforce authorization on every protected object and operation. Explicitly consider IDOR/BOLA, horizontal escalation, vertical escalation, and tenant isolation.

## Input

Validate structure and size at trust boundaries. Use parameterized queries and contextual output encoding.

## SSRF

Treat user-controlled URLs as security-sensitive. Restrict destinations and protocols where possible, validate redirects, and avoid allowing internal network access.

## CSRF and CORS

Use framework-supported CSRF protections where applicable. CORS should be an explicit allow policy rather than a blanket trust of arbitrary origins.

## Resource limits

Bound request size, upload size, concurrency, parsing complexity, and expensive operations.
