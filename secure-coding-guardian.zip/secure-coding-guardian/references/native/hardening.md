# Native Application Hardening

Consider, where supported and compatible:

- Strong compiler warnings
- Stack protection
- PIE
- RELRO
- NX/DEP
- Fortify features
- Control-flow protections
- Sanitizers in test builds

Do not treat a hardening flag as a substitute for fixing memory-safety defects.
