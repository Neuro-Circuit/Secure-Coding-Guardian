# Threat Modeling Method

For a useful threat model, document:

1. Assets
2. Actors
3. Entry points
4. Data flows
5. Trust boundaries
6. Security assumptions
7. Threats
8. Existing mitigations
9. Missing mitigations
10. Residual risk

Use STRIDE when it improves completeness. Keep the model proportional to project risk.
