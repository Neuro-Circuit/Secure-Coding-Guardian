# Secure Coding Guardian

A project-aware secure coding and security review Skill for Claude Code.

Secure Coding Guardian helps Claude reason about security while building, reviewing, testing, hardening, and releasing software.

It supports:

- Python
- C
- C++

and adapts its security focus to the project, including web, network, native, desktop, CLI, embedded, data-processing, and security-sensitive applications.

## What it does

Secure Coding Guardian is designed to work as a security-focused coding agent, not just as a vulnerability scanner.

It can:

1. Inspect the repository and project instructions.
2. Identify languages, frameworks, build systems, entry points, and trust boundaries.
3. Select an appropriate security profile.
4. Build a practical threat model.
5. Guide secure implementation.
6. Review changed and existing code.
7. Run available static-analysis and security tools.
8. Perform security-focused tests.
9. Audit dependencies and secrets.
10. Add security regression tests where practical.
11. Review the final diff.
12. Produce a clear Security Gate.

Final security status is reported as:

- `PASS`
- `PASS WITH WARNINGS`
- `FAIL`
- `UNKNOWN`

The Skill never claims that software is "100% secure".

## Security coverage

### Python

The Python guidance covers areas such as:

- Authentication and authorization
- SQL/NoSQL/LDAP injection
- Command injection and unsafe subprocess usage
- SSRF
- XSS, SSTI, CSRF, and CORS
- Path traversal and unsafe file handling
- Unsafe deserialization
- Archive and parser security
- ReDoS and resource exhaustion
- Secrets
- Cryptography
- Dependency vulnerabilities

Framework-aware review includes Django, Flask, FastAPI, and Starlette when detected.

### C

C security coverage includes:

- Buffer overflows
- Out-of-bounds access
- Use-after-free
- Double/invalid free
- Uninitialized memory
- Integer overflow and truncation
- Format strings
- Undefined behavior
- Unsafe parsing
- TOCTOU and races
- Command injection
- Path traversal
- Privilege boundaries
- Compiler and linker hardening

Relevant tooling can include ASan, UBSan, LSan, TSan, MSan, clang-tidy, Clang Static Analyzer, cppcheck, libFuzzer, and AFL++.

### C++

C++ adds analysis for:

- Ownership
- Object lifetime
- Dangling references and pointers
- Smart-pointer usage
- Iterator invalidation
- Unsafe casts
- Exception safety
- Move semantics
- Concurrency
- Serialization
- Filesystem and subprocess behavior
- FFI/ABI boundaries

The Skill favors RAII, explicit ownership, smart pointers, safe abstractions, and clear error handling.

## Project-aware security

The Skill does not apply the same checklist to every repository.

For example, a FastAPI service may prioritize:

- Authentication
- Authorization
- IDOR/BOLA
- SQL injection
- SSRF
- Request limits
- Secrets
- Dependency security

A C++ network parser may instead prioritize:

- Memory safety
- Integer handling
- Parser robustness
- Undefined behavior
- Sanitizers
- Fuzzing
- Static analysis

This project-aware behavior is one of the core goals of the Skill.

## Threat modeling

For meaningful attack surfaces, the Skill considers:

- Assets
- Actors
- Trust boundaries
- Entry points
- Data flows
- Security threats
- Mitigations
- Residual risk

STRIDE can be used where it provides useful structure.

## Workflows

The Skill includes reusable workflows for:

- Project discovery
- Secure implementation
- Security review
- Vulnerability remediation
- Release security gates

## Security testing

Depending on the project, the Skill may use:

- Unit and integration security tests
- Static analysis
- Dependency auditing
- Sanitizers
- Fuzzing
- Boundary-value tests
- Malformed-input tests
- Resource-limit tests
- Security regression tests

Tools are used only when available and appropriate. Missing tools are reported rather than silently ignored.

## Repository structure

```text
secure-coding-guardian/
├── SKILL.md
├── README.md
├── LICENSE
├── references/
├── workflows/
├── checklists/
├── scripts/
└── examples/
```

## Installation

For Claude Code, place the Skill in a supported Skills directory such as:

```text
.claude/skills/secure-coding-guardian/SKILL.md
```

or the personal Skills directory:

```text
~/.claude/skills/secure-coding-guardian/SKILL.md
```

For Claude custom Skill upload, package the complete `secure-coding-guardian/` directory as a ZIP. The ZIP must contain the Skill directory as its root.

## Limitations

Secure Coding Guardian is an engineering aid, not a guarantee of security.

Results depend on:

- Available source code
- Project configuration
- Runtime behavior
- Available tools
- Dependency visibility
- Test coverage
- Deployment environment
- External infrastructure

The Skill reports material uncertainty instead of converting missing evidence into confidence.

## Security philosophy

The goal is not to produce the largest possible vulnerability report.

The goal is to make software demonstrably safer through:

- Better design
- Safer implementation
- Evidence-based testing
- Clear remediation
- Regression prevention
- Explicit residual risk

## License

See `LICENSE`.
